import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import Principal from './src/Principal';
import Produtos from './src/Produtos';
import Detalhes from './src/Detalhes';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Principal">
        <Stack.Screen name="Principal" component={Principal} options={{ title: 'Bem-vindo!' }} />
        <Stack.Screen name="Produtos" component={Produtos} options={{ title: 'Nossas Pizzas' }} />
        <Stack.Screen name="Detalhes" component={Detalhes} options={({ route }) => ({ title: route.params.nome })} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}