import { StyleSheet, View, Image, Text, TouchableOpacity, ScrollView } from 'react-native';

export default function Detalhes({ route, navigation }) {
  const { nome, imagem, descricao } = route.params;

  function comprar() {
    // Lógica de compra pode ser implementada aqui
    alert(`Você comprou a ${nome}!`);
  }
  return (
    <ScrollView style={styles.container}>
      <Image source={imagem} style={styles.imagem} />
      <View style={styles.infoContainer}>
        <Text style={styles.nome}>{nome}</Text>
        <Text style={styles.descricao}>{descricao}</Text>
        <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.button} onPress={() => comprar()}>
          <Text style={styles.buttonText}>Comprar</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => navigation.goBack()}>
          <Text style={styles.buttonText}>Voltar</Text>
        </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#161616ff',
  },
  imagem: {
    width: '100%',
    height: 300,
    resizeMode: 'cover',
  },
  infoContainer: {
    padding: 20,
  },
  nome: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#fff',
  },
  descricao: {
    fontSize: 18,
    lineHeight: 26,
    color: '#d4d4d4ff',
    marginBottom: 25,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'grid',
    gap: 10,
  },
  button: {
    backgroundColor: '#dc3545',
   
    width: '45%',
    borderRadius: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});