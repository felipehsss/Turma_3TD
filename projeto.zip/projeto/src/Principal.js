import { StyleSheet, View, Image, TouchableOpacity, Text } from 'react-native';

export default function Principal({ navigation }) {

  function irParaProdutos() {
    navigation.navigate('Produtos');
  }

  return (
    <View style={styles.container}>
      <Image source={require('./public/dominos-Logo.png')} style={styles.logo} />
      <Image source={require('./public/banner-inicial.png')} style={styles.banner} />

      <TouchableOpacity style={styles.button} onPress={irParaProdutos}>
        <Text style={styles.buttonText}>Ver Pizzas</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#161616ff',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  logo: {
    width: 200,
    height: 100,
    resizeMode: 'contain',
    marginBottom: 20,
  },
  banner: {
    width: '100%',
    height: 200,
    resizeMode: 'contain',
    marginBottom: 30,
  },
  button: {
    backgroundColor: '#007bff',
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});