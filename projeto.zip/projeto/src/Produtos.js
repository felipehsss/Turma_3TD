import { StyleSheet, View, Image, TouchableOpacity, Text, ScrollView } from 'react-native';

const produtos = [
  {
    id: 1,
    nome: 'Pizza de Queijo',
    imagem: require('./public/pizza-queijo.jpg'),
    descricao: 'Deliciosa pizza de queijo mussarela com molho de tomate fresco.'
  },
  {
    id: 2,
    nome: 'Pizza de Pepperoni',
    imagem: require('./public/pizza-peperoni.jpg'),
    descricao: 'A clássica pizza de pepperoni com queijo mussarela derretido.'
  },
  {
    id: 3,
    nome: 'Pizza 3 Queijos',
    imagem: require('./public/pizza-3-queijos.jpg'),
    descricao: 'Uma combinação perfeita de queijos mussarela, provolone e parmesão.'
  },
  {
    id: 4,
    nome: 'Pizza de Calabresa',
    imagem: require('./public/pizza-calabresa.jpg'),
    descricao: 'Saborosa pizza de calabresa fatiada com cebola e azeitonas.'
  },
  {
    id: 5,
    nome: 'Frango com Requeijão',
    imagem: require('./public/pizza-frango-req.jpg'),
    descricao: 'Irresistível pizza de frango desfiado com requeijão cremoso.'
  },
  {
    id: 6,
    nome: 'Pizza Margherita',
    imagem: require('./public/pizza-margherita.jpg'),
    descricao: 'A tradicional pizza Margherita com mussarela, tomate e manjericão.'
  },
];

export default function Produtos({ navigation }) {

  function irParaDetalhes(produto) {
    navigation.navigate('Detalhes', produto);
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.grid}>
        {produtos.map(produto => (
          <TouchableOpacity key={produto.id} style={styles.card} onPress={() => irParaDetalhes(produto)}>
            <Image source={produto.imagem} style={styles.imagem} />
            <Text style={styles.nome}>{produto.nome}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111111ff',
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    padding: 10,
  },
  card: {
    width: '45%',
    backgroundColor: '#1d1b1bff',
    borderRadius: 10,
    padding: 10,
    marginVertical: 10,
    alignItems: 'center',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    
  },
  imagem: {
    width: 120,
    height: 120,
    borderRadius: 10,
    marginBottom: 10,
  },
  nome: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#fff',
  },
});